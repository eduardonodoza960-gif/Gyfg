package br.lantunnel.mixin;

import br.lantunnel.LanTunnelMod;
import net.minecraft.server.integrated.IntegratedServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(IntegratedServer.class)
public abstract class IntegratedServerMixin {

    // Quando o mundo e aberto para LAN com sucesso, sobe o tunel.
    @Inject(method = "openToLan", at = @At("RETURN"), require = 0)
    private void lantunnel$afterOpen(net.minecraft.world.GameMode gameMode, boolean cheats, int port,
                                     CallbackInfoReturnable<Boolean> cir) {
        try {
            if (cir.getReturnValue()) {
                LanTunnelMod.onLanOpened(port);
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    // Libera pirata. Nao e obrigatorio: se o metodo nao existir, o jogo continua sem crashar.
    @Inject(method = "isOnlineMode", at = @At("HEAD"), cancellable = true, require = 0)
    private void lantunnel$offlineMode(CallbackInfoReturnable<Boolean> cir) {
        if (LanTunnelMod.lanActive) {
            cir.setReturnValue(false);
        }
    }
}
