package br.lantunnel.mixin;

import br.lantunnel.LanTunnelMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.server.integrated.IntegratedServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(IntegratedServer.class)
public abstract class IntegratedServerMixin {

    // Quando o mundo e aberto para LAN com sucesso, sobe o tunel.
    @Inject(method = "openToLan", at = @At("RETURN"))
    private void lantunnel$afterOpen(net.minecraft.world.GameMode gameMode, boolean cheats, int port,
                                     CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValue()) {
            LanTunnelMod.onLanOpened(port);
        }
    }

    // Libera pirata: o servidor integrado deixa de exigir login da Mojang enquanto o tunel estiver ativo.
    @Inject(method = "isOnlineMode", at = @At("HEAD"), cancellable = true)
    private void lantunnel$offlineMode(CallbackInfoReturnable<Boolean> cir) {
        if (LanTunnelMod.lanActive) {
            cir.setReturnValue(false);
        }
    }
}
