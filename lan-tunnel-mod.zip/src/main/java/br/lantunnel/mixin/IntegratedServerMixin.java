package br.lantunnel.mixin;

import br.lantunnel.LanTunnelMod;
import net.minecraft.server.integrated.IntegratedServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(IntegratedServer.class)
public abstract class IntegratedServerMixin {

    // Quando o mundo abre para LAN com sucesso: libera pirata e sobe o tunel.
    @Inject(method = "openToLan", at = @At("RETURN"), require = 0)
    private void lantunnel$afterOpen(net.minecraft.world.GameMode gameMode, boolean cheats, int port,
                                     CallbackInfoReturnable<Boolean> cir) {
        try {
            if (cir.getReturnValue()) {
                // Desliga a verificacao de conta da Mojang (modo offline = pirata + original entram)
                ((IntegratedServer) (Object) this).setOnlineMode(false);
                LanTunnelMod.onLanOpened(port);
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
