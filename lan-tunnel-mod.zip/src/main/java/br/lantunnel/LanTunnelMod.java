package br.lantunnel;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class LanTunnelMod implements ClientModInitializer {
    public static volatile boolean lanActive = false;
    private static BoreTunnel tunnel;

    @Override
    public void onInitializeClient() {
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> stop());
    }

    public static synchronized void onLanOpened(int localPort) {
        stop();
        lanActive = true;
        tunnel = new BoreTunnel("bore.pub", 7835, localPort);
        tunnel.start().whenComplete((remotePort, err) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.execute(() -> {
                if (err != null) {
                    chat(Text.literal("[LAN Tunnel] Falha ao criar link publico: " + err.getMessage())
                            .formatted(Formatting.RED));
                    return;
                }
                String addr = "bore.pub:" + remotePort;
                chat(Text.literal("[LAN Tunnel] Porta local: " + localPort).formatted(Formatting.GRAY));
                chat(Text.literal("[LAN Tunnel] Link publico (pirata + original): ")
                        .formatted(Formatting.GREEN)
                        .append(Text.literal(addr).styled(s -> s
                                .withColor(Formatting.AQUA)
                                .withUnderline(true)
                                .withClickEvent(new ClickEvent(ClickEvent.Action.COPY_TO_CLIPBOARD, addr))
                                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT,
                                        Text.literal("Clique para copiar"))))));
                chat(Text.literal("[LAN Tunnel] Seu amigo coloca esse link em Multiplayer > Adicionar servidor.")
                        .formatted(Formatting.GRAY));
            });
        });
    }

    public static synchronized void stop() {
        lanActive = false;
        if (tunnel != null) {
            tunnel.stop();
            tunnel = null;
        }
    }

    private static void chat(Text t) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud != null) {
            mc.inGameHud.getChatHud().addMessage(t);
        }
    }
}
