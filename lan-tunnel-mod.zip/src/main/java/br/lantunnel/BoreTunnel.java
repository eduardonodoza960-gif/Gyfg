package br.lantunnel;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.CompletableFuture;

/** Cliente minimo do protocolo "bore" (servidor publico bore.pub, sem conta). */
public class BoreTunnel {
    private final String host;
    private final int controlPort;
    private final int localPort;
    private volatile boolean running = true;
    private volatile Socket control;

    public BoreTunnel(String host, int controlPort, int localPort) {
        this.host = host;
        this.controlPort = controlPort;
        this.localPort = localPort;
    }

    public CompletableFuture<Integer> start() {
        CompletableFuture<Integer> future = new CompletableFuture<>();
        Thread t = new Thread(() -> run(future), "LanTunnel-control");
        t.setDaemon(true);
        t.start();
        return future;
    }

    public void stop() {
        running = false;
        close(control);
    }

    private void run(CompletableFuture<Integer> future) {
        try {
            Socket s = new Socket();
            s.connect(new InetSocketAddress(host, controlPort), 10000);
            s.setSoTimeout(15000);
            control = s;
            InputStream in = s.getInputStream();
            OutputStream out = s.getOutputStream();

            send(out, "{\"Hello\":0}");
            JsonElement hello = JsonParser.parseString(readMessage(in));
            if (!hello.isJsonObject() || !hello.getAsJsonObject().has("Hello")) {
                throw new IOException("Resposta inesperada do servidor: " + hello);
            }
            future.complete(hello.getAsJsonObject().get("Hello").getAsInt());

            while (running) {
                JsonElement msg = JsonParser.parseString(readMessage(in));
                if (msg.isJsonObject()) {
                    JsonObject o = msg.getAsJsonObject();
                    if (o.has("Connection")) {
                        String id = o.get("Connection").getAsString();
                        Thread h = new Thread(() -> handle(id), "LanTunnel-conn");
                        h.setDaemon(true);
                        h.start();
                    } else if (o.has("Error")) {
                        throw new IOException(o.get("Error").getAsString());
                    }
                }
                // "Heartbeat" e ignorado
            }
        } catch (Exception e) {
            if (!future.isDone()) {
                future.completeExceptionally(e);
            }
        } finally {
            close(control);
        }
    }

    private void handle(String id) {
        Socket remote = null;
        Socket local = null;
        try {
            remote = new Socket();
            remote.connect(new InetSocketAddress(host, controlPort), 10000);
            send(remote.getOutputStream(), "{\"Accept\":\"" + id + "\"}");
            local = new Socket("127.0.0.1", localPort);
            local.setTcpNoDelay(true);
            remote.setTcpNoDelay(true);
            final Socket r = remote;
            final Socket l = local;
            Thread a = new Thread(() -> pipe(r, l), "LanTunnel-pipe-a");
            a.setDaemon(true);
            a.start();
            pipe(l, r);
        } catch (Exception ignored) {
            close(remote);
            close(local);
        }
    }

    private static void pipe(Socket from, Socket to) {
        try {
            InputStream in = from.getInputStream();
            OutputStream out = to.getOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                out.flush();
            }
        } catch (IOException ignored) {
        } finally {
            close(from);
            close(to);
        }
    }

    private static void send(OutputStream out, String json) throws IOException {
        out.write(json.getBytes(StandardCharsets.UTF_8));
        out.write(0);
        out.flush();
    }

    private static String readMessage(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        int b;
        while ((b = in.read()) != -1) {
            if (b == 0) {
                return bos.toString(StandardCharsets.UTF_8);
            }
            bos.write(b);
        }
        throw new IOException("Conexao fechada pelo servidor do tunel");
    }

    private static void close(Socket s) {
        if (s != null) {
            try { s.close(); } catch (IOException ignored) {}
        }
    }
}
